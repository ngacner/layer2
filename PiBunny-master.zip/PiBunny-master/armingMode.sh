#/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
LED R 
/bin/ATTACKMODE STORAGE "FILE_IMAGE=/scripts/system.img" 
LED GB 
