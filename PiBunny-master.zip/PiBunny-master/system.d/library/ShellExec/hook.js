alert('This is where your evil JavaScript file would go')
