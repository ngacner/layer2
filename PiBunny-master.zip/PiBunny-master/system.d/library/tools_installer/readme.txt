Tools Installer for Bash Bunny
Version 1.1.0

Moves tools from the tools_to_install/ USB disk to /pentest on the Bash Bunny
When installation succeeds, install.sh will be renamed to install.sh.INSTALLED

A list of installed tools is created on the USB disk as installed-tools.txt

Purple Blinking.................Moving tools
Purple Solid....................Tools moved
Amber Blinking..................Setup tools
Red Solid.......................Tool installation failed
White Solid.....................Installation completed successfully