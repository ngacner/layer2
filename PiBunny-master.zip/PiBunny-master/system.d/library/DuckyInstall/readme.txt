DuckToolkit installer for Bash Bunny. 
Adds support for new languages. and uses the Ducktoolkit python library for encoding. 

Version 1.0.0

Moves the libary files to /tools
Update Q and QUACK to point to the new library
Writes error to /root/ducky.log

Purple Blinking.................Moving tools
Purple Solid....................Tools moved
Amber Blinking..................Setup tools
Red Solid.......................Tool installation failed
White Solid.....................Installation completed successfully
