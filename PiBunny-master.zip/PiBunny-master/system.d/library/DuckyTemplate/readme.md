# Ducky Script Template for Bash Bunnys

Author: @kevthehermit
Version: Version 1.0

## Description

Boiler Plate for running ducky scripts on the Bash Bunny

## Configuration

HID or HID STORAGE

## Requirements

Install DuckToolkit payload for extra language support

## STATUS

| LED              | Status                                |
| ---------------- | ------------------------------------- |
| Red              | Failed to open script file            |
| Amber            | Script Running                        |
| Green            | Finished                              |

