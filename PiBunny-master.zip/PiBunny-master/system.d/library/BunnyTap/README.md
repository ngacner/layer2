# BunnyTap for Bash Bunnys

Author: Whistle Master
Version: Version 1.0
Credit: <a href="https://twitter.com/samykamkar" target=_blank>@SamyKamkar</a>

## Description

Based on PoisonTap created by <a href="https://twitter.com/samykamkar" target=_blank>@SamyKamkar</a> || <a href="https://samy.pl" target=_blank>https://samy.pl</a>

## Configuration

Configured for Windows by default. Swap RNDIS_ETHERNET for ECM_ETHERNET on Mac/*nix

## Requirements

dnsspoof must be installed (use install.sh)

## Install LED STATUS

| LED              | Status                                 |
| ---------------- | -------------------------------------- |
| White (blinking) | Dependencies not met                   |
| Purple           | Setup                                  |
| Purple (blinking)| Installing dependencies                |
| White (blinking) | Finished installing                    |
| Red (blinking)   | Install failed, no Internet connection |

## Payload LED STATUS

| LED              | Status                                 |
| ---------------- | -------------------------------------- |
| Green (blinking) | BunnyTap Setup                         |
| Blue             | BunnyTap running					    |

## Discussion
[Hak5 Forum Thread](https://forums.hak5.org/index.php?/topic/40240-poisontap-on-the-bunny/ "Hak5 Forum Thread")
