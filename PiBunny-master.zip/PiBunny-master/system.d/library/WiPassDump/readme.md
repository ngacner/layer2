# WiPassDump for Bash Bunnys

* Author: samdeg555
* Version: Version 1.0
* Target: Windows

## Description

Dumps saved Wi-Fi infos including clear text passwords to the bash bunny
Saves to the loot folder on the Bash Bunny USB Mass Storage partition in WiPassDump folder.

## Configuration

None needed. 

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Red (blinking)     | Setting up                                   |
| Blue (blinking)    | Attack running                               |
| Purple (blinking)  | Almost done (cleaning up)                    |
| Green              | Attack Complete                              |

## Discussion
None yet. 
