# RDP Checker for Bash Bunnys

Author: Hak5Darren
Version: Version 1.0

## Description

Checks whether RDP is enabled on target machine
Green=Enabled. Red=Disables.

## Requirements

impacket must be installed in /pentest (run tools-installer if not)

## STATUS

| LED              | Status                                |
| ---------------- | ------------------------------------- |
| White (blinking) | Dependencies not installed.           |
| Purple           | Setup.                                |
| Amber (blinking) | Scanning                              |
| Red              | RDP not enabled.                      |
| Green            | RDP enabled.                          |

## Discussion

[Hak5 Forum Thread]( "Hak5 Forum Thread")
